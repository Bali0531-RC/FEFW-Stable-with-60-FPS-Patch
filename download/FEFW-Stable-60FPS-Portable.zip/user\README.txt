Eden keeps its keys, firmware, settings and saves in this folder. Delete it to use %APPDATA%\eden instead.
