FEFW Stable with 60 FPS Patch - portable Windows x64 build
(Eden FE: Fortune's Weave fork, based on xDarkWindx eden-fefw 1.12)

Runs on any 64-bit Windows 10/11 PC with a Vulkan-capable GPU. No CPU-specific code
and the Microsoft C++ runtime is included, so nothing needs installing.

GETTING STARTED
1. Extract this whole folder somewhere (not inside Program Files) and run eden.exe.
2. Add your game folder: double-click the empty game list and choose the folder.
3. Only for encrypted NSP/XCI dumps: add your own keys (Tools > Install Decryption Keys)
   and firmware (Tools > Install Firmware). Loose-file dumps (exefs/romfs) don't need
   either; just dismiss the keys prompt if it appears.

No games, keys or firmware are included: use your own, dumped from your own console.
Everything (settings, saves, keys, firmware, shader cache) stays in the user\ folder here,
so this doesn't touch any other Eden install. To move it, move the whole folder.

SETTINGS are already set up, including a Fortune's Weave profile (right-click the game >
Properties) with the 12 GB memory layout the game needs, GPU mode Fast and asynchronous shaders.
Only controls need setting: Emulation > Configure > Controls.

60 FPS MOD (Fortune's Weave) - already installed in user\load\04007EF01F8AE000\60fps.
It is on by default. If you have problems with it (uneven frame pacing, glitches),
DELETE the folder user\load\04007EF01F8AE000\60fps to go back to the normal 30 fps;
unticking it under Add-Ons isn't always enough.
It only works with the game version whose build ID starts DB93B0125F485060;
other versions just ignore it.

Changes from upstream: the start-up check that clears empty save profile folders no longer
crashes when Windows refuses the delete, and never deletes a folder it could not read.

Licence: GPL-3.0-or-later (see LICENSE). The full source for this build is in source.zip.
Built with MSVC 19.51.36260 on 2026-11-05.
