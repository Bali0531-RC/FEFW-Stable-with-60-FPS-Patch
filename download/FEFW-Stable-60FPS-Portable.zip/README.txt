Fortune's Eden (FEFW Stable with 60 FPS Patch) v1.6 - portable Windows x64 build
(Eden FE: Fortune's Weave fork, built on Duck912's eden-ns2-fe and xDarkWindx's eden-fefw 1.12)

Runs on any 64-bit Windows 10/11 PC with a Vulkan-capable GPU. No CPU-specific code
and the Microsoft C++ runtime is included, so nothing needs installing.

GETTING STARTED
1. Extract this whole folder somewhere (not inside Program Files) and run Fortune's Eden.exe.
2. Add your game folder: double-click the empty game list and choose the folder.

LEGAL USE ONLY. Piracy is not acceptable and is not supported in any way. No games, keys,
firmware or other Nintendo files are included. Use your own legally obtained copy of the game, dumped from your own
console, as loose files (exefs/romfs) or a single .nup file, with keys and firmware dumped
from that same console. Not affiliated with, endorsed by or sponsored by Nintendo or NVIDIA.
SAVES ARE STORED HERE, next to Fortune's Eden.exe (user\nand), NOT in %APPDATA%\eden.
Loose files and .nup now share the same saves. Saves made with loose files in older versions
are copied across automatically the first time.
Everything (settings, saves, shader cache) stays in the user\ folder here, so this doesn't
touch any other Eden install. To move it, move the whole folder. Deleting it deletes your saves.

SETTINGS are already set up globally (Emulation > Configure), so they apply however the game
is dumped or packed: the 12 GB memory layout the game needs, GPU accuracy Fast, asynchronous
shaders on, vsync off, 16x anisotropic filtering, VRAM Usage Mode Conservative (up to three
quarters of the card's video memory), ASTC recompression Auto, AMD FSR window filter at 0%
sharpness and FXAA anti-aliasing.

ASTC RECOMPRESSION (Graphics > Advanced): Auto picks BC3, which the graphics card now
re-compresses itself: a quarter of the video memory of Uncompressed, without the freezes BC3
used to cause. Uncompressed needs a lot of video memory: on a card with less than 20 GB the game
can run out and stutter or drop to single-digit FPS. The log says what Auto picked.
Only controls need setting: Emulation > Configure > Controls.

NVIDIA DLSS (optional, GeForce RTX cards): Emulation > Configure > Graphics, tick
"Use NVIDIA DLSS in place of the game's DLSS", then click "Download from NVIDIA" in the panel
below it (NVIDIA's files aren't included). Takes effect when the game starts. It replaces the
game's own lightweight DLSS with the full PC version: sharper, with less ghosting.

60 FPS MOD (Fortune's Weave) - included in user\load\04007EF01F8AE000\60fps, but
OFF by default. 30 fps is the game's native framerate on Switch 2 and runs smoothly
everywhere, while 60 fps can feel choppy.
Fast PC? It's fairly smooth on high-end CPUs at 1x resolution (FSR upscales to your
screen); higher resolutions roughly double the choppiness. To try it, right-click the
game > Properties > Add-Ons and tick 60fps.
If it causes problems, untick it; if it still feels choppy, DELETE the folder
user\load\04007EF01F8AE000\60fps (unticking it isn't always enough).
It only works with the game version whose build ID starts DB93B0125F485060;
other versions just ignore it.
ULTRAWIDE 3440x1440 (optional, OFF by default) - for 21:9 monitors: Emulation > Configure >
Graphics, tick "Ultrawide 3440x1440 (21:9) for Fortune's Weave", then start the game and play
fullscreen. It widens the 3D camera and keeps the HUD, menus and movies centred at 16:9
(movies get black bars). Kompas9's patch (MIT, licenses\ultrawide-kompas9); only for game
version 1.1.0 (build ID DB93B0125F485060).

New in v1.6:
- ASTC textures are re-compressed to BC3 on the GPU (from Eglantine, Duck912), so battle starts
  no longer freeze while textures convert, and Auto picks BC3 on every card (about half the video memory).
- Smoother play when video memory fills up: ASTC textures unused for 30 s are freed early.

New in v1.5.2:
- Fixes a crash inside the NVIDIA driver (nvoglv64.dll) a few minutes into some sessions with
  NVIDIA DLSS on: drawing DLSS's output could start with a framebuffer the texture cache had
  just removed. From Eglantine (Duck912).

New in v1.5.1:
- Game updates: the main menu shows the update's version (1.1.0, not 1.0.0), also for .nup
  files that don't record one; loose dumps can carry an update in an updates\<number>\ folder.
- ASTC recompression Auto (see above), and big cards may use three quarters of their video
  memory instead of about 7 GB.
- Laptops and 4-core CPUs: sound no longer stutters in battles (audio threads at top priority;
  the GPU thread split turns itself off with 4 or fewer fast cores).
- Threads wait properly on newer CPUs (from Eglantine); fewer shader hitches during fades;
  crash fixes for window resizing, failed shaders, NVIDIA depth copies and stopping the game.
- Cutscene video keeps up with the voices on slower PCs.
- Logs show frame pacing every 10 s and video memory use every minute.

Changes from upstream:
- Optional NVIDIA DLSS in place of the game's own DLSS (from Duck912's work in Eglantine).
- The sky no longer turns black after opening the map: the texture cache threw away the game's
  sky colour table while the map covered the screen, without keeping what the GPU had drawn.
  Small images the GPU drew are now always kept.
- No more recurring stutter from an experiment left on by mistake in v1.3.1 to v1.4.2 (held
  CPU writes reached the GPU a frame late, so frames came out unevenly).
- CPU Clocks (Boost/Overclock) is gone: it ran the game's clock 1.7-2x fast, so cutscene voices
  dropped out and dialogue animations ended early.
- Slightly smoother busy scenes: the GPU back thread answers most "has the GPU written here?"
  checks from a page bitmap instead of searching a tree (same answers).
- Much smaller logs: no line per frame, one line per unmapped memory read, so long sessions'
  logs stay small enough to send.
- Optional ultrawide 3440x1440 (21:9) setting, off by default: Kompas9's patch (MIT), built in.
- Bath scenes no longer lose their background: a compute shader using a shared-memory
  compare-and-swap (ATOMS.CAS) is now translated instead of skipped.
- Cutscenes keep up: AV1 videos are decoded several frames at once, so the busiest 1440p
  cutscenes no longer drop the game to about 5 FPS.
- A user folder copied from another build uses its own saves and folders here, not the old
  build's (and Open Save Data Location opens the one next to this exe).
- Smoother 60 FPS in busy scenes: texture-handle tables the game builds on the GPU and never
  changes are no longer waited for once a frame.
- Fewer shader-compile stutters: translated shaders are reused between pipelines that share
  them (Wael3rd, from PokeDinner).
- Loose-file dumps use the game's real ID, so their saves sit with .nup saves.
- Shutdown and restart fixes: no hang when the audio renderer outlives its manager
  (kraibse), and a second game in the same window no longer hangs (Takoroka); both from
  PokeDinner (an Eglantine fork). Clearer logs for missing keys and unsupported commands
  (xDarkWindx).
- Loads .nup game files (NUP loader ported from Djihads80's Eglantine, GPL-3.0).
- AMD fix: shader registers read before being written are zero, as on NVIDIA, instead of
  garbage (stray coloured patches on AMD GPUs). From Eglantine (arisqz), GPL-3.0.
- The start-up check that clears empty save profile folders no longer crashes when Windows
  refuses the delete, and never deletes a folder it could not read.

Licence: GPL-3.0-or-later (see LICENSE). The full source for this build is in source.zip.
Built with MSVC 19.51.36260 on 2026-11-08, with profile-guided optimisation trained on Fortune's Weave.
